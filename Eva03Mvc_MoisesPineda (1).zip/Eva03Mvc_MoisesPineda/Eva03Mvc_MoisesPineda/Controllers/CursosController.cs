﻿using Eva03Mvc_MoisesPineda.Models;
using Eva03Mvc_MoisesPineda.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class CursosController : Controller
    {
        public ActionResult Index()
        {
            var cursos = new List<Curso>
            {
                new Curso { Id = 1, Nombre = "Programación II", Duracion = 80 },
                new Curso { Id = 2, Nombre = "Base de Datos", Duracion = 60 },
                new Curso { Id = 3, Nombre = "Redes", Duracion = 60 }
            };

            return View(cursos);
        }
    }
}