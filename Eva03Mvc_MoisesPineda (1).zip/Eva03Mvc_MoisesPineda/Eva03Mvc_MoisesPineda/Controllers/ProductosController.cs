﻿using Eva03Mvc_MoisesPineda.Models;
using Eva03Mvc_MoisesPineda.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class ProductosController : Controller
    {
        private static List<Producto> productos = new List<Producto>
        {
            new Producto { Id = 1, Nombre = "Camisa", Precio = 15.50m },
            new Producto { Id = 2, Nombre = "Zapatos", Precio = 40m },
            new Producto { Id = 3, Nombre = "Gorra", Precio = 8.75m }
        };

        public ActionResult Index()
        {
            return View(productos);
        }

        public ActionResult Detalle(int id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            var producto = productos.FirstOrDefault(p => p.Id == id);

            if (producto == null)
            {
                return HttpNotFound();
            }

            return View(producto);
        }
    }
}