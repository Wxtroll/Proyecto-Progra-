﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Mensaje = "¡Bienvenido a mi aplicación MVC!";
            ViewBag.Fecha = DateTime.Now;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();

        }
        public ActionResult SimularError()
        {

            try
            {
                throw new Exception("Error simulado");
            }
            catch (Exception)
            {
                ViewBag.Mensaje = "Ocurrió un problema. Intenta de nuevo más tarde.";
                return View("Error");
            }

        }
    }
}