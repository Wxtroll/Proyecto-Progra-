﻿
using Eva03Mvc_MoisesPineda.Models;
using Eva03Mvc_MoisesPineda.Models;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class ClientesController : Controller
    {
        [HttpGet]
        public ActionResult Registrar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Registrar(Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return View(cliente);
            }

            return View("Confirmacion", cliente);
        }
    }
}