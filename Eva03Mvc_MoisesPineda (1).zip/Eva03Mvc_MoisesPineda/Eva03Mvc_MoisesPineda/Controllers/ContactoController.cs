﻿
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class ContactoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}