﻿using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class EstudiantesController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}