﻿using Eva03Mvc_MoisesPineda.Models;
using Eva03Mvc_MoisesPineda.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda.Controllers
{
    public class CategoriasController : Controller
    {
        private static List<Categoria> categorias = new List<Categoria>
        {
            new Categoria { Id = 1, Nombre = "Ropa" },
            new Categoria { Id = 2, Nombre = "Calzado" }
        };

        public ActionResult Index()
        {
            return View(categorias);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Categoria categoria)
        {
            categoria.Id = categorias.Any() ? categorias.Max(c => c.Id) + 1 : 1;
            categorias.Add(categoria);
            TempData["Mensaje"] = "Categoría agregada correctamente";
            return RedirectToAction("Index");
        }
    }
}