﻿using System.Web;
using System.Web.Mvc;

namespace Eva03Mvc_MoisesPineda
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
