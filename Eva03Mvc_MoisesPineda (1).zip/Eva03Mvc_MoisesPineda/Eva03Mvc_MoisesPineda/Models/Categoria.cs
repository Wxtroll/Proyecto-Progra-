﻿namespace Eva03Mvc_MoisesPineda.Models
{
    public class Categoria
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}