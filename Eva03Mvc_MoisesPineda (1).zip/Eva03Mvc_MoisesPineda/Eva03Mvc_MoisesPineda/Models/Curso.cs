﻿namespace Eva03Mvc_MoisesPineda.Models
{
    public class Curso
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int Duracion { get; set; }
    }
}